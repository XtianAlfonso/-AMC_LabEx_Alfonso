import React, { useState } from 'react';
import { SafeAreaView, ScrollView, View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';

const App = () => {
  const [currentSection, setCurrentSection] = useState('name');

  const resumeData = {
    imageUrl: require('./assets/Ako.jpg'),
    name: 'Alfonso, Christian M.',
    course: 'Bachelor of Science in Information Technology',
    education: {
      elementary: 'Silvestre Lazaro Elementary School',
      elementaryYear: '2014',
      highSchool: 'General Tiburcio De Leon National High School',
      highSchoolYear: '2017',
      seniorSchool: 'Dagohoy National High School',
      seniorSchoolYear: '2019',
      college: 'Global Reciprocal Colleges',
      collegeYear: '2021',
    },

    about: `I am currently taking a Bachelor of Scince in Information Technology in 9th Avenue Caloocan City. I love to sing and i served God thru singing `,
   
   
    projects:
      {
        projectName: ' Pamaskong Handog ',
        imageSrc: 'https://scontent.fmnl33-6.fna.fbcdn.net/v/t39.30808-6/416239323_715580247341168_4242476110245998665_n.jpg?_nc_cat=107&cb=99be929b-b574a898&ccb=1-7&_nc_sid=a73e89&_nc_eui2=AeGM3hXIIFn6gIWzF3_yRbU_xhEFw5qTaIHGEQXDmpNogSO7IAZzfnF84mafm7eIPuB3vlbLjgqzyf78sDqjcIc7&_nc_ohc=nYvR6jX4ZX4AX_916bG&_nc_ht=scontent.fmnl33-6.fna&oh=00_AfB4wKIBMT-DqG-X5p5it3sPjVascmNa3N-VRaSHkFz3Qw&oe=65DB2B0C',
        description: 'In this project, we are targeting to give Christmas gifts to more than 2000 families and to feed the poor. Our parish already does this every coming holiday season, the grace of this is to serve something on the table every Christmas and help the poor. The contents of the seasonal offering are one kilo of spaghetti, hotdogs, can goods and 5kg of Rice. May God Bless Us!.',
      },

    contact: {
      mobile: '0992-557-5034',
      email: 'xtianalfonso17@gmail.com', 
    },
  };

const handlePress = () => {
  setCurrentSection((prevSection) => {
    switch (prevSection) {
      case 'name':
        return 'education';
      case 'education':
        return 'about';
      case 'about':
        return 'projects';
      case 'projects':
          return 'contact'; 
        case 'contact':
          return 'name'; 
        default:
          return 'name';
    }
  });
};

  return (
    <SafeAreaView style={{ flex: 1 }}>
      <ScrollView contentContainerStyle={styles.container}>
        <TouchableOpacity onPress={handlePress} style={styles.contentContainer}>
          {currentSection === 'name' && (
            <>
              <Image source={resumeData.imageUrl} style={styles.image} />
              <View style={styles.textContainer}>
                <Text style={styles.header}>{resumeData.name}</Text>
                <Text style={styles.info}>{resumeData.course}</Text>
              </View>
            </>
          )}

          {currentSection === 'education' && (
            <View style={styles.textContainer}>
              <Text style={styles.header1}>Education:</Text>
              <Text style={styles.projectTitle}>
                {'\n'}College:
                {'\n'}
                  </Text>
                <Text style={styles.info1}>{resumeData.education.college}</Text>
                {' | '}
                {resumeData.education.collegeYear}
           
              <Text style={styles.projectTitle}>
                {'\n'}High School:
                {'\n'}
                  </Text>
                <Text style={styles.info1}>{resumeData.education.highSchool}</Text>
                {' | '}
                {resumeData.education.highSchoolYear}
     
              <Text style={styles.projectTitle}>
                {'\n'}Elementary:
                {'\n'}
                  </Text>
                <Text style={styles.info1}>{resumeData.education.elementary}</Text>
                {' | '}
                {resumeData.education.elementaryYear}
           
            </View>
          )}

          {currentSection === 'about' && (
            <View style={styles.textContainer}>
              <Text style={styles.header1}>About me:{'\n'}</Text>
              <Text style={styles.about}>{resumeData.about}</Text>
            </View>
          )}

{currentSection === 'projects' && (
  <View style={styles.projectsContainer}>
    <Text style={styles.header1}>Projects:</Text>
    <Text style={styles.projectTitle}>{resumeData.projects.projectName}</Text>
    <Image source={{ uri: resumeData.projects.imageSrc }} style={styles.projectImage} />
    <Text style={styles.projectLink}>{resumeData.projects.link}</Text>
    <Text style={styles.projectDescription}> {resumeData.projects.description}</Text>
  </View>
)}

          {currentSection === 'contact' && (
            <View style={styles.contactContainer}>
              <Text style={styles.header1}>Contact Me:{'\n'}</Text>
              <Text style={styles.info1}>
                {'\n'}Mobile: {resumeData.contact.mobile}
                {'\n'}Email: {resumeData.contact.email}
              </Text>
            </View>
          )}

        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  contentContainer: {
    alignItems: 'center',
    maxWidth: 600,
  },
  image: {
    width: 150,
    height: 150,
    borderRadius: 75,
    marginBottom: 20,
  },
  textContainer: {
    alignSelf: 'stretch',
  },
  header: {
    fontSize: 35,
    fontWeight: 'bold',
    marginBottom: 5,
    textAlign: 'center',
  },
  header1: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 5,
    textAlign: 'left',
  },
  info: {
    fontSize: 20,
    alignSelf: 'flex-start',
    textAlign: 'center',
  },
  info1: {
    fontSize: 20,
    alignSelf: 'flex-start',
    textAlign: 'left',

  },
  about: {
    fontSize: 20,
    textAlign: 'left',
    alignSelf: 'flex-start',
  },
   projectsContainer: {
    alignSelf: 'stretch',
    marginTop: 20,
  },
  projectTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 5,
    textAlign: 'left',
  },
  projectImage: {
    width: 300,
    height: 300,
    marginBottom: 10,
    alignSelf: 'center',
  },
  projectLink: {
    fontSize: 16,
    marginBottom: 5,
    textAlign: 'center',
  },
  projectDescription: {
    fontSize: 16,
    marginBottom: 10,
    textAlign: 'justify',
  },


});

export default App;